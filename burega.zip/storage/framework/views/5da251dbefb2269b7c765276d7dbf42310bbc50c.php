
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?> ">
    <meta name="csrf-token" value="<?php echo e(csrf_token()); ?>"/>
    <script>window.Laravel={ csrfToken:'<?php echo e(csrf_token()); ?>'} </script>
    
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, minimal-ui">

   
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Dashboard | Application</title>

   
    
    <!-- mes scripts -->
    <link rel="shortcut icon" href="./images/pnud.png">
    <!-- fin mes scripts -->

    
    <link rel="stylesheet" href="<?php echo e(asset('css/canvas.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/beagle.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/swot.css')); ?>">
     
    

    
    <!-- <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>"> -->

    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.x/css/font-awesome.min.css" rel="stylesheet">

    
</head>
<body>


	<?php if(isset(auth()->user()->email)): ?>
	

	<script type="text/javascript">
	        window.emerfine = <?php echo json_encode([
	            'baseURL' => url('/'),
	            'apiBaseURL' => url('/api'),
	            'user' => auth()->user()
	        ]); ?>

	</script>


	<?php else: ?>

	<script type="text/javascript">
	        window.emerfine = <?php echo json_encode([
	            'baseURL' => url('/'),
	            'apiBaseURL' => url('/api'),
	            'user' => array(
	            	'id'	=> null,
	            	'name'	=> null,
	            	'email'	=> null,
	            	'id_role'	=> null,
	            )
	        ]); ?>

	</script>
	
	<?php endif; ?>



	<div id="app">

	    <app-init></app-init>
	</div>

	

	<script src="<?php echo e(mix('js/app.js')); ?>"></script>

	
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\mes_projets\burega\resources\views/backend/dashbord.blade.php ENDPATH**/ ?>