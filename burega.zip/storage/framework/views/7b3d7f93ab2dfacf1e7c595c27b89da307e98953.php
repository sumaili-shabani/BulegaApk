
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?> ">
        <meta name="csrf-token" value="<?php echo e(csrf_token()); ?>"/>
        <script>window.Laravel={ csrfToken:'<?php echo e(csrf_token()); ?>'} </script>
        
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, minimal-ui">

       
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

        <title>Login | PNUD Laboratoire d'acceleration</title>

       
        
        <!-- mes scripts -->
        <link rel="shortcut icon" href="./images/pnud.png">
        <!-- fin mes scripts -->

       <link rel="shortcut icon" href="<?php echo e(asset('images/pnud.png')); ?>">
        <!-- <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>"> -->
    </head>
    <body>


    <?php if(isset(auth()->user()->email)): ?>
    <script type="text/javascript">
      window.location="<?php echo e(url('/dashbord')); ?>" 
    </script>
    <?php endif; ?>


    <div id="app">
          <login /> 
         
    </div>
    
   
   <script type="text/javascript">
            window.emerfine = <?php echo json_encode([
                'baseURL' => url('/'),
                'apiBaseURL' => url('/api'),
                'user' => auth()->user()
            ]); ?>

     </script>
    <script src="<?php echo e(mix('/js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\mes_projets\burega\resources\views/auth/register.blade.php ENDPATH**/ ?>