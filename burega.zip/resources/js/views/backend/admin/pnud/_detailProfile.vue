<template>
    <div>
        {{title}}
    </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";
export default {
    data(){
        return{
            title:"Detail de profile"
        }

    },
    created(){

    },
    methods:{

    },

}
</script>
<style scoped>
</style>
