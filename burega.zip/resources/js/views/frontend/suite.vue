<template>
    <div>
        {{ title }}
    </div>
</template>
<script>

export default {
    data(){
        return{
            title:"Suite de question des questions",
        }
    }
}
</script>

