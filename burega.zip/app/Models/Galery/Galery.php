<?php

namespace App\Models\Galery;

use Illuminate\Database\Eloquent\Model;

class Galery extends Model
{
    //
    protected $fillable = [
        'photo'
    ];
}
