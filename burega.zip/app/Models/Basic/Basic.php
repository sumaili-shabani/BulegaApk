<?php

namespace App\Models\Basic;

use Illuminate\Database\Eloquent\Model;

class Basic extends Model
{
    //
    protected $fillable = [
        'apropos', 'travail', 'don','structure'
    ];
}
