<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class BusnessPlan extends Model
{
    //
    protected $fillable = [
        'id_entreprise', 'busness_plan'
    ];
}
