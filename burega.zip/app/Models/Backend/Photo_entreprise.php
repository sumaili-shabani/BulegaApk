<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class Photo_entreprise extends Model
{
    //
    protected $fillable = [
        'id_entreprise', 'photo'
    ];
}
