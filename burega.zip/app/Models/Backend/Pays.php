<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class Pays extends Model
{
    //
    protected $fillable = [
        'nomPays'
    ];
}
