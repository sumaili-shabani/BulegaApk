<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class LinkCanvas extends Model
{
    //
    protected $fillable = [
        'ceo','titre','message',
    ];
}
