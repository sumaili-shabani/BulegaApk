<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class Swot extends Model
{
    //
    protected $fillable = [
        'ceo','titre','message',
    ];
}
