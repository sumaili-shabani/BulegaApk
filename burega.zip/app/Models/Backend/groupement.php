<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class groupement extends Model
{
    //
    protected $fillable = [
        'idChef','nomGroup'
    ];
}
