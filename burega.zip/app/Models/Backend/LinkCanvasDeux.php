<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class LinkCanvasDeux extends Model
{
    //
    protected $fillable = [
        'id_coach','ceo','titre','message',
    ];
}
