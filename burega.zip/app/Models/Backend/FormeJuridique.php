<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class FormeJuridique extends Model
{
    //
    protected $fillable = [
        'nomForme'
    ];
}
