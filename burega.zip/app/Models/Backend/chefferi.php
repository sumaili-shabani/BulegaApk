<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class chefferi extends Model
{
    //
    protected $fillable = [
        'idTer','nomTer'
    ];
}
