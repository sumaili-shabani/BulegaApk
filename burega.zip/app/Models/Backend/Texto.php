<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class Texto extends Model
{
    //
    protected $fillable = [
        'phone','message','etat',
    ];
}
