<?php

namespace App\Models\Backend;

use Illuminate\Database\Eloquent\Model;

class Territoire extends Model
{
    //
    protected $fillable = [
        'nomTerritoire'
    ];
    
}
